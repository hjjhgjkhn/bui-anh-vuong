<?php
    $conn_bav = new mysqli("localhost","root","","qlbh_buianhvuongcntt3");
?>