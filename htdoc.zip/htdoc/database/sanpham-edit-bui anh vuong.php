<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sửa bùi anh vương 2210900084</title>
</head>
<body>
    <?php
    $error_bav="";
    include("ketnoi-buianhvuong.php");
    if(isset($_POST["btn_bav"])){
        $MA_2210900084 = $_POST["MA_2210900084"];
        $TEN_2210900084 = $_POST["TEN_2210900084"];
        $SL_2210900084 = $_POST["SL_2210900084"];
        $DG_2210900084 = $_POST["DG_2210900084"];
        $ANH_2210900084 = $_POST["ANH_2210900084"];
        $TRANGTHAI_2210900084 = $_POST["TRANGTHAI_2210900084"];
        if($_POST["ANH"]!=""){
            $ANH_2210900084 = $_POST["ANH"];
        }
        $sql_update_bav = "UPDATE bang_buianhvuong SET TEN_2210900084='$TEN_2210900084' ";
        $sql_update_bav .= " ,SL_2210900084=$SL_2210900084";
        $sql_update_bav .= " ,DG_2210900084=$DG_2210900084";
        $sql_update_bav .= " ,ANH_2210900084='$ANH_2210900084'";
        $sql_update_bav .= " ,TRANGTHAI_2210900084=$TRANGTHAI_2210900084";
        $sql_update_bav .= " WHERE MA_2210900084= '$MA_2210900084'";
        //die($sql_update_bav);
        if($conn_bav->query($sql_update_bav)){
            header("location:sanpham-list-buianhvuong.php");
        }else{
            $error_bav="lỗi cập nhập, ". $conn_bav->error. "<p> $sql_update_bav ";
        }
    }
    if(isset($_GET["id"])){
        $sql_edit_bav = "SELECT * FROM bang_buianhvuong WHERE MA_2210900084 ='" . $_GET["id"] . "'";
        $result_bav = $conn_bav->query($sql_edit_bav);
        $row_bav = $result_bav->fetch_array();
    }
    ?>
    

    <header>
        <h1> sửa sản phẩm ... bùi anh vương 2210900084</h1>
    </header>
    <form action="" method="post">
        <div>
            <label> Mã </label>
            <input type="text" name="MA_2210900084" value="<?php echo $row_bav["MA_2210900084"];?>">
        </div>
        <div>
            <label> Tên </label>
            <input type="text" name="TEN_2210900084"value="<?php echo $row_bav["TEN_2210900084"];?>">
        </div>
        <div>
            <label> Sl </label>
            <input type="text" name="SL_2210900084"value="<?php echo $row_bav["SL_2210900084"];?>">
        </div>
        <div>
            <label> đơn giá </label>
            <input type="text" name="DG_2210900084"value="<?php echo $row_bav["DG_2210900084"];?>">
        </div>
        <div>
            <label> ảnh </label>
            <input type="hidden" name="ANH_2210900084" value="<?php echo $row_bav["ANH_2210900084"];?>">
            <input type="file" name="ANH">
        </div>
        <div>
            <label> Trạng thái </label>
            <input type="radio" value="1" name="TRANGTHAI_2210900084" id="TT1"
                <?php echo $row_bav["TRANGTHAI_2210900084"]==1?"checked":""
                ?>
            > 
            <label for="TT1"> Hiện</label>
            <input type="radio" value="0" name="TRANGTHAI_2210900084" id="TT2"
                <?php echo $row_bav["TRANGTHAI_2210900084"]==0?"checked":""
                ?>
            >
            <label for="TT2"> Ẩn</label>
        </div>
        <input type="submit" value="thêm" name="btn_bav">
        <div>
            <?php
            if(isset($error_bav)){
                echo $error_bav;
            }
            ?>
        </div>
    </form>
</body>
</html>