<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - bùi anh vương </title>
</head>
<body>
    <?php 
        include("ketnoi-buianhvuong.php");
        $sql_bav = "SELECT * FROM danhmuc_bav WHERE 1=1 ";
        $result_bav = $conn_bav->query($sql_bav);
     ?>
    <section>
        <h1>DANH SÁCH SẢN PHẨM - bùi anh vương </h1>
        <hr/>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>Stt</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    if($result_bav->num_rows>0){
                        $stt=0;
                        while($row_bav=$result_bav->fetch_array()):
                            $stt++;
                ?>
                    <tr>
                        <td><?php echo $stt; ?></td>
                        <td><?php echo $row_bav["MADM_bav"]; ?></td>
                        <td><?php echo $row_bav["TENDM_bav"]; ?></td>
                        <td><?php echo $row_bav["TRANGTHAI_bav"]; ?></td>
                        <td>
                            <a href="danhmuc-edit-bav.php?MADM_bav=<?php echo $row_bav["MADM_bav"];?>">
                                Sửa
                            </a>
                            |
                            <a href="danhmuc-list-bav.php?MADM_bav=<?php echo $row_bav["MADM_bav"];?>"
                                onclick="if(confirm('Bạn có muốn xóa không')){return true;}else{return false;}">
                                Xóa
                            </a>
                        </td>
                    </tr>
                <?php 
                        endwhile;
                    }else{
                ?>
                    <tr>
                        <td colspan="9">Chưa có dữ liệu</td>
                    </tr>
                <?php
                    };
                ?>
            </tbody>
        </table>
    </section>

    <?php 
        if(isset($_GET["MADM_bav"])){
            $MADM_bav = $_GET["MADM_bav"];
            $sql_delete_bav = "DELETE FROM danhmuc_bav WHERE MADM_bav='$MADM_bav'";
            if($conn_bav->query($sql_delete_bav)){
                header("Location: danhmuc-list-bav.php");
            }else{
                echo "<script> alert('lỗi xóa'); </script>";
            }
        }
    ?>
</body>
</html>