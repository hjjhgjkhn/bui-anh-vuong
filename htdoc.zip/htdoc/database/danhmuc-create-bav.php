<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-vuduckhoa.php");
        $sql_pb_bav = "SELECT * FROM danhmuc_bav  WHERE 1=1";
        $res_pb_bav = $conn_bav->query($sql_pb_bav);
        if(isset($_POST["btnSubmit_bav"])){
            $MADM_bav = $_POST["MADM_bav"];
            $TENDM_bav = $_POST["TENDM_bav"];
            $TRANGTHAI_bav = $_POST["TRANGTHAI_bav"];
            $sql_check_bav = "SELECT MADM_bav FROM danhmuc_bav WHERE MADM_bav = 'MADM_bav' ";
            $res_check_bav = $conn_bav->query($sql_check_bav);
            if($res_check_bav->num_rows>0){
                $error_message_bav="Lỗi trùng khóa chính.";
            }
            $sql_insert_bav = "INSERT INTO danhmuc_bav ('MADM_bav', 'TENDM_bav', 'TRANGTHAI_bav')";
            $sql_insert_bav.="VALUES ('$MADM_bav','$TENDM_bav','$TRANGTHAI_bav');";
            if($conn_bav->query($sql_insert_bav)){
                header("Location: danhmuc-lisT-bav.php"); 
            }else{
                $error_message_bav="Lỗi thêm mới". mysqli_error($conn_bav);
            }
        }
        ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_bav" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                        <input type="text" name="MADM_bav" id="MADM_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TENDM_bav" id="TENDM_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_bav" >
                                <option value="1" selected>Hoạt động</option>
                                <option value="0" selected>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="reset" value="Làm lại" name="btnReset_bav">
                        </td>
                    </tr>
                </tbody>
            </table>    
        </form>
        <a href="danhmuc-list-bav.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>