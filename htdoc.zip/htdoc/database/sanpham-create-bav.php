<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-buianhvuong.php");
        $sql_pb_bav = "SELECT * FROM sanpham_bav  WHERE 1=1";
        $res_pb_bav = $conn_bav->query($sql_pb_bav);
        if(isset($_POST["btnSubmit_bav"])){
            $SPID_bav = $_POST["SPID_bav"];
            $TESP_bav = $_POST["TESP_bav"];
            $SOLUONG_bav = $_POST["SOLUONG_bav"];
            $GIAMUA_bav = $_POST["GIAMUA_bav"];
            $GIABAN_bav = $_POST["GIABAN_bav"];
            $TRANGTHAI_bav = $_POST["TRANGTHAI_bav"];
            $MADM_bav = $_POST["MADM_bav"];
            $sql_check_bav = "SELECT SPID_bav FROM sanpham_bav WHERE SPID_bav = 'SPID_bav' ";
            $res_check_bav = $conn_bav->query($sql_check_bav);
            if($res_check_bav->num_rows>0){
                $error_message_bav="Lỗi trùng khóa chính.";
            }
            $sql_insert_bav = "INSERT INTO sanpham_bav ('SPID_bav', 'TESP_bav', 'SOLUONG_bav','GIAMUA_bav', 'GIABAN_bav', 'TRANGTHAI_bav', 'MADM_bav')";
            $sql_insert_bav.="VALUES ('$SPID_bav','$TESP_bav','$SOLUONG_bav','$GIAMUA_bav','$GIABAN_bav','$TRANGTHAI_bav','$MADM_bav');";
            if($conn_bav->query($sql_insert_bav)){
                header("Location: sanpham-lisT-bav.php"); 
            }else{
                $error_message_bav="Lỗi thêm mới". mysqli_error($conn_bav);
            }
        }
        ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_bav" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã</td>
                        <td>
                            <input type="text" name="SPID_bav" id="SPID_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TESP_bav" id="TESP_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá mua</td>
                        <td>
                            <input type="text" name="GIAMUA_bav" id="GIAMUA_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá bán</td>
                        <td>
                            <input type="text" name="GIABAN_bav" id="GIABAN_bav">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_bav" >
                                <option value="1" selected>Hoạt động</option>
                                <option value="0" selected>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                        <input type="text" name="MADM_bav" id="MADM_bav">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="reset" value="Làm lại" name="btnReset_bav">
                        </td>
                    </tr>
                </tbody>
            </table>    
        </form>
        <a href="sanpham-list-bav.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>