<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - bùi anh vương</title>
</head>
<body>
    <?php 
        include("ketnoi-buianhvuong.php");
        $sql_bav = "SELECT * FROM bang_buianhvuong WHERE 1 =1 ";
        $result_bav = $conn_bav->query($sql_bav);
    ?>
    <?php
        if(isset($_GET["id"])){
            $sql_bav_delete = "DELETE FROM bang_buianhvuong WHERE MA_2210900084='" . $_GET["id"] . "'";
            if($conn_bav->query($sql_bav_delete)){
                header("location:sanpham-list-buianhvuong.php");
            }
        }
    ?>
    <header>
        <h1> Danh sách hiển thị sản phẩm -bùi anh vương-2210900084</h1>
    </header>
    <section>
        <a href="sanpham-add-buianhvuong.php">thêm mới</a>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>Stt</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Sl</th>
                    <th>đơn giá</th>
                    <th>ảnh</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                        $stt_bav=0;
                        while($row_bav = $result_bav->fetch_array()){
                            $stt_bav ++;
                ?>
                    <tr>
                        <td><?php echo $stt_bav; ?></td>
                        <td><?php echo $row_bav["MA_2210900084"]; ?></td>
                        <td><?php echo $row_bav["TEN_2210900084"]; ?></td>
                        <td><?php echo $row_bav["SL_2210900084"]; ?></td>
                        <td><?php echo $row_bav["DG_2210900084"]; ?></td>
                        <td><?php echo $row_bav["ANH_2210900084"]; ?></td>
                        <td><?php echo 
                                $row_bav["TRANGTHAI_2210900084"]==true?" yêu em":"ẩn";  ?></td>
                        <td>
                            <a href="sanpham-edit-buianhvuong.php?id=<?php echo $row_bav["MA_2210900084"]; ?>"> sửa</a> 
                            |
                            <a href="sanpham-list-buianhvuong.php?id=<?php echo $row_bav["MA_2210900084"]; ?>"> xóa</a>
                        </td>
                        
                    </tr>
                <?php 
                        }
                ?>
            </tbody>
        </table>
    </section>

</body>
</html>